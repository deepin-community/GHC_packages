Composite - A QUnit Addon For Running Multiple Test Files
================================

Composite is a QUnit addon that, when handed an array of files, will
open each of those files inside of an iframe, run the tests and
display the results as a single suite of QUnit tests.

